from distutils.core import setup

setup(
        name            = 'sisiwuxi_nester',
        version         = '1.0.1',
        py_modules      = ['sisiwuxi_nester'],
        author          = 'sisi',
        author_email    = 'sisiwuxi@hotmail.com',
        description     = 'A simple printer of nested lists',
     )

